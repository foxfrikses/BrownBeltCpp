#pragma once

#include "Response.h"

#include <string>

namespace Responses
{
  class GetBus : public IResponse {
  public:
    ~GetBus() override = default;
    void Access(IResponseVisitor& v) override;
    
    std::string busName;
    int stopsOnRoute = 0;
    int uniqueStops = 0;
    double routeLength = 0.0;
    double curvature = 0.0;
    int requestId = 0;
  };
}
