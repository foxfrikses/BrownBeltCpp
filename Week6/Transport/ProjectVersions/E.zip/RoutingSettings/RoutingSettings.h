#pragma once

struct RoutingSettings {
  int busWaitTime = 0;
  double busVelocity = 0.0;
};