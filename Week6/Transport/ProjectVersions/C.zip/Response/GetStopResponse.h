#pragma once

#include "Response.h"

#include <optional>
#include <vector>
#include <string>
#include <string_view>

namespace Responses {
  class GetStop : public IResponse {
  public:
    ~GetStop() override = default;
    void Access(IResponseVisitor& v) override;
    
    std::string stopName;
    std::optional<std::vector<std::string>> buses;
    int requestId = 0;
  };
}
