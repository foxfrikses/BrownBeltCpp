#include "ResponseWriteToStreamVisitor.h"

using namespace std;

namespace ResponseVisitor {
  WriteToStream::WriteToStream(std::ostream &stream)
      : stream(stream) {
    stream.precision(6);
  }
  
  void WriteToStream::Visit(Responses::GetBus &response) {
    stream << "Bus " << response.busName << ": ";
    
    if (response.stopsOnRoute == 0) {
      stream << "not found";
    } else {
      stream << response.stopsOnRoute << " stops on route, " <<
             response.uniqueStops << " unique stops, " <<
             response.routeLength << " route length, " <<
             response.curvature << " curvature";
    }
    
    stream << '\n';
  }
  
  void WriteToStream::Visit(Responses::GetStop &response) {
    stream << "Stop " << response.stopName << ": ";
    
    if (!response.buses.has_value()) {
      stream << "not found";
    } else if (response.buses->empty()) {
      stream << "no buses";
    } else {
      stream << "buses";
      for (auto &bus: *response.buses) {
        stream << ' ' << bus;
      }
    }
    
    stream << '\n';
  }
}