#include "RequestComputeStatVisitor.h"

#include "GetBusResponse.h"
#include "GetStopResponse.h"

#include "GetBusRequest.h"
#include "GetStopRequest.h"

namespace RequestVisitor
{
  ComputeStat::ComputeStat(const TransportDirectory &directory)
      : directory(directory)
  {}
  
  ComputeStat::~ComputeStat() = default;
  
  std::vector<ComputeStat::ResponsePtr>
  ComputeStat::ReleaseResponses() {
    return std::move(responses);
  }
  
  void ComputeStat::Visit(Requests::GetBus &request) {
    const auto infoOpt = directory.GetBusInfo(request.name);
    
    auto response = std::make_unique<Responses::GetBus>();
    response->requestId = request.id;
    
    if (infoOpt.has_value()) {
      auto &info = infoOpt.value();
  
      response->busName = info.busName;
      response->routeLength = info.routeLength;
      response->stopsOnRoute = info.stops.size();
      response->uniqueStops = info.uniqueStops;
      response->curvature = info.curvature;
    }
    else {
      response->busName = request.name;
    }
    
    responses.push_back(std::move(response));
  }
  
  void ComputeStat::Visit(Requests::GetStop &request) {
    const auto infoOpt = directory.GetStopInfo(request.name);
    
    auto response = std::make_unique<Responses::GetStop>();
    response->requestId = request.id;
  
    if (infoOpt.has_value()) {
      auto &info = infoOpt.value();
      
      response->stopName = info.stopName;
      response->buses->assign(info.buses.begin(), info.buses.end());
    }
    else {
      response->stopName = request.name;
    }
    
    responses.push_back(std::move(response));
  }
}
